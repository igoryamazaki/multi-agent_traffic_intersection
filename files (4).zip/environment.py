# ============================================================
# environment.py - Ambiente Urbano de Trânsito (Ute)
#
# Conforme Fig. 1 (EAA): tanto o AV-agent quanto o Ethical
# Agent percebem o ambiente via sensores. O AV-agent age
# no ambiente via atuadores (hit the brakes, turn left...).
# ============================================================

from maspy import *


class AmbienteUrbano(Environment):

    def __init__(self, env_name):
        super().__init__(env_name)
        # Cenário: semáforo verde + pedestre atravessando
        # (Exemplo 2 do artigo: Green Light + Pedestrian in a hurry)
        self.create(Percept("semaforo_aberto", True))
        self.create(Percept("pedestre_detectado", True))
        self.create(Percept("obstaculo", False))
        self.create(Percept("veiculo_detectado", False))

    def executar_movimento(self, src, movimento):
        """Atuador: VA executa movimento no ambiente."""
        self.print(f"Movimento executado por {src}: {movimento}")
        if movimento in ["frear", "desviar"]:
            self.print(f"Conflito resolvido com ação: {movimento}")
            self.create(Percept("conflito_resolvido", {
                "acao": movimento, "agente": str(src)
            }))

    def registrar_evento(self, src, evento):
        self.print(f"Evento registrado por {src}: {evento}")
        self.create(Percept("evento_registrado", evento))
